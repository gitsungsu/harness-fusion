"""Argument-array execution with bounded reads and process-tree cancellation."""
import os
import shutil
import signal
import subprocess
import tempfile
import time


def stop(process):
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                       capture_output=True, timeout=10, check=False)
    else:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    if process.poll() is None:
        process.kill()
    process.wait()


def execute(command, root, timeout, prompt="", env=None):
    started = time.monotonic()
    command = list(command)
    command[0] = shutil.which(command[0]) or command[0]
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        try:
            process = subprocess.Popen(command, cwd=root, stdin=subprocess.PIPE,
                                       stdout=stdout, stderr=stderr, env=env,
                                       start_new_session=os.name != "nt",
                                       creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0)
        except OSError as exc:
            return {"returncode": 127, "stdout": "", "stderr": str(exc), "seconds": 0}
        try:
            process.communicate(prompt.encode("utf-8"), timeout=max(0.01, timeout))
            code = process.returncode
        except subprocess.TimeoutExpired:
            stop(process)
            code = 124
        except BaseException:
            stop(process)
            raise
        stdout.seek(0, 2)
        size = stdout.tell()
        stdout.seek(0)
        out = stdout.read(1024 * 1024).decode("utf-8", errors="replace")
        if size > 1024 * 1024:
            code = 125
        stderr.seek(0, 2)
        stderr.seek(max(0, stderr.tell() - 32000))
        err = stderr.read().decode("utf-8", errors="replace")
    if code == 124:
        err += "\nProcess timeout"
    if code == 125:
        err += "\nOutput exceeded 1 MiB protocol limit"
    return {"returncode": code, "stdout": out, "stderr": err,
            "seconds": round(time.monotonic() - started, 3)}
